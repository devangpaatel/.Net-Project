using CurrencyConverter.Services;

namespace CurrencyConverter
{
    public partial class Form1 : Form
    {
        private CurrencyExchangeService? _exchangeService;
        private List<string>? _currencies;
        private bool _isInitialized = false;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes the application when the form loads
        /// </summary>
        private async void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                UpdateStatus("Loading currencies...");

                _exchangeService = new CurrencyExchangeService();
                await LoadCurrenciesAsync();

                _isInitialized = true;
                UpdateStatus("Ready - Static Exchange Rates");
            }
            catch (Exception ex)
            {
                ShowError("Initialization Error", $"Failed to initialize:\n\n{ex.Message}");
                UpdateStatus("Error - Initialization failed");
            }
        }

        /// <summary>
        /// Loads available currencies into the combo boxes with names and country info
        /// </summary>
        private async Task LoadCurrenciesAsync()
        {
            try
            {
                if (_exchangeService == null)
                    return;

                // Get currencies with names for display
                _currencies = await _exchangeService.GetAvailableCurrenciesWithNamesAsync();

                cmbFromCurrency.DataSource = new List<string>(_currencies);
                cmbToCurrency.DataSource = new List<string>(_currencies);

                // Find and set defaults
                var eurDefault = _currencies.FirstOrDefault(x => x.StartsWith("EUR -"));
                var usdDefault = _currencies.FirstOrDefault(x => x.StartsWith("USD -"));

                if (eurDefault != null)
                    cmbFromCurrency.SelectedItem = eurDefault;
                if (usdDefault != null)
                    cmbToCurrency.SelectedItem = usdDefault;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to load currencies", ex);
            }
        }

        /// <summary>
        /// Performs currency conversion on button click
        /// </summary>
        private async void BtnConvert_Click(object sender, EventArgs e)
        {
            if (!_isInitialized || _exchangeService == null)
            {
                ShowError("Error", "Application not initialized");
                return;
            }

            try
            {
                if (!ValidateInputs(out var amount, out var fromCurrency, out var toCurrency))
                    return;

                UpdateStatus("Converting...");
                btnConvert.Enabled = false;

                var result = await _exchangeService.ConvertCurrencyAsync(fromCurrency, toCurrency, amount);

                txtResult.Text = result.ConvertedAmount.ToString("F2");
                lblExchangeRate.Text = $"1 {result.FromCurrency} ({result.FromCountry}) = {result.ExchangeRate:F4} {result.ToCurrency} ({result.ToCountry})";

                UpdateStatus("Conversion successful");
            }
            catch (Exception ex)
            {
                ShowError("Conversion Error", ex.Message);
                UpdateStatus("Conversion failed");
            }
            finally
            {
                btnConvert.Enabled = true;
            }
        }

        /// <summary>
        /// Validate user inputs before conversion
        /// </summary>
        private bool ValidateInputs(out decimal amount, out string fromCurrency, out string toCurrency)
        {
            amount = 0;
            fromCurrency = string.Empty;
            toCurrency = string.Empty;

            if (!decimal.TryParse(txtAmount.Text, out amount) || amount < 0)
            {
                ShowError("Invalid Amount", "Please enter a valid positive number");
                txtAmount.Focus();
                return false;
            }

            if (cmbFromCurrency.SelectedItem == null || cmbToCurrency.SelectedItem == null)
            {
                ShowError("Missing Selection", "Please select both currencies");
                return false;
            }

            // Extract currency code from formatted string (e.g., "USD - US Dollar (United States)" -> "USD")
            var fromCurrencyFormatted = cmbFromCurrency.SelectedItem.ToString() ?? string.Empty;
            var toCurrencyFormatted = cmbToCurrency.SelectedItem.ToString() ?? string.Empty;

            fromCurrency = CurrencyExchangeService.ExtractCurrencyCode(fromCurrencyFormatted);
            toCurrency = CurrencyExchangeService.ExtractCurrencyCode(toCurrencyFormatted);

            if (string.IsNullOrEmpty(fromCurrency) || string.IsNullOrEmpty(toCurrency))
            {
                ShowError("Invalid Selection", "Please select valid currencies");
                return false;
            }

            if (fromCurrency == toCurrency)
            {
                ShowError("Invalid Selection", "Please select different currencies");
                cmbToCurrency.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// Display error message to user
        /// </summary>
        private void ShowError(string title, string message)
        {
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        /// <summary>
        /// Update status bar message
        /// </summary>
        private void UpdateStatus(string message)
        {
            if (toolStripStatusLabel1 != null)
            {
                toolStripStatusLabel1.Text = message;
            }
        }




        /// <summary>
        /// Refresh button click - converts USD to INR with default amount of 1
        /// </summary>
        private async void BtnRefresh_Click(object sender, EventArgs e)
        {
            if (!_isInitialized || _exchangeService == null)
            {
                ShowError("Error", "Application not initialized");
                return;
            }

            try
            {
                UpdateStatus("Refreshing ");
                btnRefresh.Enabled = false;

                // Set the dropdowns to USD and INR
                var usdOption = _currencies?.FirstOrDefault(x => x.StartsWith("USD -"));
                var inrOption = _currencies?.FirstOrDefault(x => x.StartsWith("INR -"));

                if (usdOption != null && inrOption != null)
                {
                    cmbFromCurrency.SelectedItem = usdOption;
                    cmbToCurrency.SelectedItem = inrOption;
                }

                // Set amount to 1
                txtAmount.Text = "1";

                // Perform the conversion
                var result = await _exchangeService.ConvertCurrencyAsync("USD", "INR", 1);

                txtResult.Text = result.ConvertedAmount.ToString("F2");
                lblExchangeRate.Text = $"1 {result.FromCurrency} ({result.FromCountry}) = {result.ExchangeRate:F4} {result.ToCurrency} ({result.ToCountry})";

                UpdateStatus("Refresh complete");
            }
            catch (Exception ex)
            {
                ShowError("Refresh Error", ex.Message);
                UpdateStatus("Refresh failed");
            }
            finally
            {
                btnRefresh.Enabled = true;
            }
        }

        /// <summary>
        /// Form closing event - cleanup resources
        /// </summary>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _exchangeService?.Dispose();
        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbToCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
