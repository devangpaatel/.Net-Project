using System.Text.Json.Serialization;

namespace CurrencyConverter.Models
{
    public class FrankfurterResponse
    {
        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }

        [JsonPropertyName("base")]
        public string? Base { get; set; }

        [JsonPropertyName("date")]
        public string? Date { get; set; }

        [JsonPropertyName("rates")]
        public Dictionary<string, decimal>? Rates { get; set; }
    }

    public class ConversionResult
    {
        public decimal Amount { get; set; }
        public string? FromCurrency { get; set; }
        public string? FromCountry { get; set; }
        public string? ToCurrency { get; set; }
        public string? ToCountry { get; set; }
        public decimal ExchangeRate { get; set; }
        public decimal ConvertedAmount { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class CurrenciesResponse
    {
        [JsonExtensionData]
        public Dictionary<string, object?>? Currencies { get; set; }
    }

    public class CurrencyInfo
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? CountryName { get; set; }
        public string? Symbol { get; set; }
        public string? Region { get; set; }
    }

    public class CurrencyCountryData
    {
        public string? CurrencyCode { get; set; }
        public string? CountryName { get; set; }
        public string? CurrencyName { get; set; }
        public string? Region { get; set; }
    }

    /// <summary>
    /// Static helper for currency-to-country mapping with 100+ currencies
    /// </summary>
    public static class CurrencyCountryMapper
    {
        public static readonly Dictionary<string, CurrencyCountryData> CurrencyMapping = new()
        {
            // Europe (20)
            { "EUR", new() { CurrencyCode = "EUR", CountryName = "Eurozone", CurrencyName = "Euro", Region = "Europe" } },
            { "GBP", new() { CurrencyCode = "GBP", CountryName = "United Kingdom", CurrencyName = "British Pound", Region = "Europe" } },
            { "CHF", new() { CurrencyCode = "CHF", CountryName = "Switzerland", CurrencyName = "Swiss Franc", Region = "Europe" } },
            { "SEK", new() { CurrencyCode = "SEK", CountryName = "Sweden", CurrencyName = "Swedish Krona", Region = "Europe" } },
            { "NOK", new() { CurrencyCode = "NOK", CountryName = "Norway", CurrencyName = "Norwegian Krone", Region = "Europe" } },
            { "DKK", new() { CurrencyCode = "DKK", CountryName = "Denmark", CurrencyName = "Danish Krone", Region = "Europe" } },
            { "ISK", new() { CurrencyCode = "ISK", CountryName = "Iceland", CurrencyName = "Icelandic Króna", Region = "Europe" } },
            { "CZK", new() { CurrencyCode = "CZK", CountryName = "Czech Republic", CurrencyName = "Czech Koruna", Region = "Europe" } },
            { "HUF", new() { CurrencyCode = "HUF", CountryName = "Hungary", CurrencyName = "Hungarian Forint", Region = "Europe" } },
            { "PLN", new() { CurrencyCode = "PLN", CountryName = "Poland", CurrencyName = "Polish Zloty", Region = "Europe" } },
            { "RON", new() { CurrencyCode = "RON", CountryName = "Romania", CurrencyName = "Romanian Leu", Region = "Europe" } },
            { "HRK", new() { CurrencyCode = "HRK", CountryName = "Croatia", CurrencyName = "Croatian Kuna", Region = "Europe" } },
            { "BGN", new() { CurrencyCode = "BGN", CountryName = "Bulgaria", CurrencyName = "Bulgarian Lev", Region = "Europe" } },
            { "RSD", new() { CurrencyCode = "RSD", CountryName = "Serbia", CurrencyName = "Serbian Dinar", Region = "Europe" } },
            { "BAM", new() { CurrencyCode = "BAM", CountryName = "Bosnia & Herzegovina", CurrencyName = "Convertible Mark", Region = "Europe" } },
            { "ALL", new() { CurrencyCode = "ALL", CountryName = "Albania", CurrencyName = "Albanian Lek", Region = "Europe" } },
            { "MDL", new() { CurrencyCode = "MDL", CountryName = "Moldova", CurrencyName = "Moldovan Leu", Region = "Europe" } },
            { "UAH", new() { CurrencyCode = "UAH", CountryName = "Ukraine", CurrencyName = "Ukrainian Hryvnia", Region = "Europe" } },
            { "BYN", new() { CurrencyCode = "BYN", CountryName = "Belarus", CurrencyName = "Belarusian Ruble", Region = "Europe" } },
            { "GEL", new() { CurrencyCode = "GEL", CountryName = "Georgia", CurrencyName = "Georgian Lari", Region = "Asia" } },

            // Americas (18)
            { "USD", new() { CurrencyCode = "USD", CountryName = "United States", CurrencyName = "US Dollar", Region = "Americas" } },
            { "CAD", new() { CurrencyCode = "CAD", CountryName = "Canada", CurrencyName = "Canadian Dollar", Region = "Americas" } },
            { "MXN", new() { CurrencyCode = "MXN", CountryName = "Mexico", CurrencyName = "Mexican Peso", Region = "Americas" } },
            { "BRL", new() { CurrencyCode = "BRL", CountryName = "Brazil", CurrencyName = "Brazilian Real", Region = "Americas" } },
            { "ARS", new() { CurrencyCode = "ARS", CountryName = "Argentina", CurrencyName = "Argentine Peso", Region = "Americas" } },
            { "CLP", new() { CurrencyCode = "CLP", CountryName = "Chile", CurrencyName = "Chilean Peso", Region = "Americas" } },
            { "COP", new() { CurrencyCode = "COP", CountryName = "Colombia", CurrencyName = "Colombian Peso", Region = "Americas" } },
            { "PEN", new() { CurrencyCode = "PEN", CountryName = "Peru", CurrencyName = "Peruvian Sol", Region = "Americas" } },
            { "UYU", new() { CurrencyCode = "UYU", CountryName = "Uruguay", CurrencyName = "Uruguayan Peso", Region = "Americas" } },
            { "BOB", new() { CurrencyCode = "BOB", CountryName = "Bolivia", CurrencyName = "Boliviano", Region = "Americas" } },
            { "VES", new() { CurrencyCode = "VES", CountryName = "Venezuela", CurrencyName = "Venezuelan Bolívar", Region = "Americas" } },
            { "JMD", new() { CurrencyCode = "JMD", CountryName = "Jamaica", CurrencyName = "Jamaican Dollar", Region = "Americas" } },
            { "TTD", new() { CurrencyCode = "TTD", CountryName = "Trinidad & Tobago", CurrencyName = "Trinidad Dollar", Region = "Americas" } },
            { "BSD", new() { CurrencyCode = "BSD", CountryName = "Bahamas", CurrencyName = "Bahamian Dollar", Region = "Americas" } },
            { "BZD", new() { CurrencyCode = "BZD", CountryName = "Belize", CurrencyName = "Belize Dollar", Region = "Americas" } },
            { "CRC", new() { CurrencyCode = "CRC", CountryName = "Costa Rica", CurrencyName = "Costa Rican Colón", Region = "Americas" } },
            { "GTQ", new() { CurrencyCode = "GTQ", CountryName = "Guatemala", CurrencyName = "Guatemalan Quetzal", Region = "Americas" } },
            { "HNL", new() { CurrencyCode = "HNL", CountryName = "Honduras", CurrencyName = "Honduran Lempira", Region = "Americas" } },

            // Asia-Pacific (36)
            { "JPY", new() { CurrencyCode = "JPY", CountryName = "Japan", CurrencyName = "Japanese Yen", Region = "Asia-Pacific" } },
            { "CNY", new() { CurrencyCode = "CNY", CountryName = "China", CurrencyName = "Chinese Yuan", Region = "Asia-Pacific" } },
            { "INR", new() { CurrencyCode = "INR", CountryName = "India", CurrencyName = "Indian Rupee", Region = "Asia-Pacific" } },
            { "SGD", new() { CurrencyCode = "SGD", CountryName = "Singapore", CurrencyName = "Singapore Dollar", Region = "Asia-Pacific" } },
            { "HKD", new() { CurrencyCode = "HKD", CountryName = "Hong Kong", CurrencyName = "Hong Kong Dollar", Region = "Asia-Pacific" } },
            { "AUD", new() { CurrencyCode = "AUD", CountryName = "Australia", CurrencyName = "Australian Dollar", Region = "Asia-Pacific" } },
            { "NZD", new() { CurrencyCode = "NZD", CountryName = "New Zealand", CurrencyName = "New Zealand Dollar", Region = "Asia-Pacific" } },
            { "KRW", new() { CurrencyCode = "KRW", CountryName = "South Korea", CurrencyName = "South Korean Won", Region = "Asia-Pacific" } },
            { "TWD", new() { CurrencyCode = "TWD", CountryName = "Taiwan", CurrencyName = "New Taiwan Dollar", Region = "Asia-Pacific" } },
            { "THB", new() { CurrencyCode = "THB", CountryName = "Thailand", CurrencyName = "Thai Baht", Region = "Asia-Pacific" } },
            { "MYR", new() { CurrencyCode = "MYR", CountryName = "Malaysia", CurrencyName = "Malaysian Ringgit", Region = "Asia-Pacific" } },
            { "PHP", new() { CurrencyCode = "PHP", CountryName = "Philippines", CurrencyName = "Philippine Peso", Region = "Asia-Pacific" } },
            { "IDR", new() { CurrencyCode = "IDR", CountryName = "Indonesia", CurrencyName = "Indonesian Rupiah", Region = "Asia-Pacific" } },
            { "PKR", new() { CurrencyCode = "PKR", CountryName = "Pakistan", CurrencyName = "Pakistani Rupee", Region = "Asia-Pacific" } },
            { "BDT", new() { CurrencyCode = "BDT", CountryName = "Bangladesh", CurrencyName = "Bangladesh Taka", Region = "Asia-Pacific" } },
            { "LKR", new() { CurrencyCode = "LKR", CountryName = "Sri Lanka", CurrencyName = "Sri Lankan Rupee", Region = "Asia-Pacific" } },
            { "MMK", new() { CurrencyCode = "MMK", CountryName = "Myanmar", CurrencyName = "Myanmar Kyat", Region = "Asia-Pacific" } },
            { "KHR", new() { CurrencyCode = "KHR", CountryName = "Cambodia", CurrencyName = "Cambodian Riel", Region = "Asia-Pacific" } },
            { "LAK", new() { CurrencyCode = "LAK", CountryName = "Laos", CurrencyName = "Lao Kip", Region = "Asia-Pacific" } },
            { "VND", new() { CurrencyCode = "VND", CountryName = "Vietnam", CurrencyName = "Vietnamese Dong", Region = "Asia-Pacific" } },
            { "MNT", new() { CurrencyCode = "MNT", CountryName = "Mongolia", CurrencyName = "Mongolian Tugrik", Region = "Asia" } },
            { "KGS", new() { CurrencyCode = "KGS", CountryName = "Kyrgyzstan", CurrencyName = "Kyrgyzstani Som", Region = "Asia" } },
            { "TJD", new() { CurrencyCode = "TJD", CountryName = "Tajikistan", CurrencyName = "Tajikistani Somoni", Region = "Asia" } },
            { "TMT", new() { CurrencyCode = "TMT", CountryName = "Turkmenistan", CurrencyName = "Turkmenistani Manat", Region = "Asia" } },
            { "AFN", new() { CurrencyCode = "AFN", CountryName = "Afghanistan", CurrencyName = "Afghan Afghani", Region = "Asia" } },
            { "NPR", new() { CurrencyCode = "NPR", CountryName = "Nepal", CurrencyName = "Nepalese Rupee", Region = "Asia-Pacific" } },
            { "BTN", new() { CurrencyCode = "BTN", CountryName = "Bhutan", CurrencyName = "Bhutanese Ngultrum", Region = "Asia-Pacific" } },
            { "MVR", new() { CurrencyCode = "MVR", CountryName = "Maldives", CurrencyName = "Maldivian Rufiyaa", Region = "Asia-Pacific" } },
            { "FJD", new() { CurrencyCode = "FJD", CountryName = "Fiji", CurrencyName = "Fijian Dollar", Region = "Asia-Pacific" } },
            { "WST", new() { CurrencyCode = "WST", CountryName = "Samoa", CurrencyName = "Samoan Tālā", Region = "Asia-Pacific" } },
            { "SBD", new() { CurrencyCode = "SBD", CountryName = "Solomon Islands", CurrencyName = "Solomon Islands Dollar", Region = "Asia-Pacific" } },
            { "PNG", new() { CurrencyCode = "PNG", CountryName = "Papua New Guinea", CurrencyName = "Papua New Guinean Kina", Region = "Asia-Pacific" } },
            { "VUV", new() { CurrencyCode = "VUV", CountryName = "Vanuatu", CurrencyName = "Vanuatu Vatu", Region = "Asia-Pacific" } },
            { "AMD", new() { CurrencyCode = "AMD", CountryName = "Armenia", CurrencyName = "Armenian Dram", Region = "Asia" } },
            { "AZN", new() { CurrencyCode = "AZN", CountryName = "Azerbaijan", CurrencyName = "Azerbaijani Manat", Region = "Asia" } },
            { "KZT", new() { CurrencyCode = "KZT", CountryName = "Kazakhstan", CurrencyName = "Kazakhstani Tenge", Region = "Asia" } },

            // Middle East & North Africa (15)
            { "AED", new() { CurrencyCode = "AED", CountryName = "United Arab Emirates", CurrencyName = "UAE Dirham", Region = "Middle East" } },
            { "SAR", new() { CurrencyCode = "SAR", CountryName = "Saudi Arabia", CurrencyName = "Saudi Riyal", Region = "Middle East" } },
            { "QAR", new() { CurrencyCode = "QAR", CountryName = "Qatar", CurrencyName = "Qatari Riyal", Region = "Middle East" } },
            { "KWD", new() { CurrencyCode = "KWD", CountryName = "Kuwait", CurrencyName = "Kuwaiti Dinar", Region = "Middle East" } },
            { "BHD", new() { CurrencyCode = "BHD", CountryName = "Bahrain", CurrencyName = "Bahraini Dinar", Region = "Middle East" } },
            { "OMR", new() { CurrencyCode = "OMR", CountryName = "Oman", CurrencyName = "Omani Rial", Region = "Middle East" } },
            { "JOD", new() { CurrencyCode = "JOD", CountryName = "Jordan", CurrencyName = "Jordanian Dinar", Region = "Middle East" } },
            { "ILS", new() { CurrencyCode = "ILS", CountryName = "Israel", CurrencyName = "Israeli Shekel", Region = "Middle East" } },
            { "EGP", new() { CurrencyCode = "EGP", CountryName = "Egypt", CurrencyName = "Egyptian Pound", Region = "Africa" } },
            { "TND", new() { CurrencyCode = "TND", CountryName = "Tunisia", CurrencyName = "Tunisian Dinar", Region = "Africa" } },
            { "DZD", new() { CurrencyCode = "DZD", CountryName = "Algeria", CurrencyName = "Algerian Dinar", Region = "Africa" } },
            { "MAD", new() { CurrencyCode = "MAD", CountryName = "Morocco", CurrencyName = "Moroccan Dirham", Region = "Africa" } },
            { "LBP", new() { CurrencyCode = "LBP", CountryName = "Lebanon", CurrencyName = "Lebanese Pound", Region = "Middle East" } },
            { "SYP", new() { CurrencyCode = "SYP", CountryName = "Syria", CurrencyName = "Syrian Pound", Region = "Middle East" } },
            { "IQD", new() { CurrencyCode = "IQD", CountryName = "Iraq", CurrencyName = "Iraqi Dinar", Region = "Middle East" } },

            // Central Asia
            { "UZS", new() { CurrencyCode = "UZS", CountryName = "Uzbekistan", CurrencyName = "Uzbekistani Som", Region = "Asia" } },

            // Africa (30)
            { "ZAR", new() { CurrencyCode = "ZAR", CountryName = "South Africa", CurrencyName = "South African Rand", Region = "Africa" } },
            { "NGN", new() { CurrencyCode = "NGN", CountryName = "Nigeria", CurrencyName = "Nigerian Naira", Region = "Africa" } },
            { "GHS", new() { CurrencyCode = "GHS", CountryName = "Ghana", CurrencyName = "Ghanaian Cedi", Region = "Africa" } },
            { "KES", new() { CurrencyCode = "KES", CountryName = "Kenya", CurrencyName = "Kenyan Shilling", Region = "Africa" } },
            { "TZS", new() { CurrencyCode = "TZS", CountryName = "Tanzania", CurrencyName = "Tanzanian Shilling", Region = "Africa" } },
            { "UGX", new() { CurrencyCode = "UGX", CountryName = "Uganda", CurrencyName = "Ugandan Shilling", Region = "Africa" } },
            { "ZMW", new() { CurrencyCode = "ZMW", CountryName = "Zambia", CurrencyName = "Zambian Kwacha", Region = "Africa" } },
            { "ZWL", new() { CurrencyCode = "ZWL", CountryName = "Zimbabwe", CurrencyName = "Zimbabwean Dollar", Region = "Africa" } },
            { "BWP", new() { CurrencyCode = "BWP", CountryName = "Botswana", CurrencyName = "Botswana Pula", Region = "Africa" } },
            { "LSL", new() { CurrencyCode = "LSL", CountryName = "Lesotho", CurrencyName = "Lesotho Loti", Region = "Africa" } },
            { "MZN", new() { CurrencyCode = "MZN", CountryName = "Mozambique", CurrencyName = "Mozambican Metical", Region = "Africa" } },
            { "AOA", new() { CurrencyCode = "AOA", CountryName = "Angola", CurrencyName = "Angolan Kwanza", Region = "Africa" } },
            { "BIF", new() { CurrencyCode = "BIF", CountryName = "Burundi", CurrencyName = "Burundian Franc", Region = "Africa" } },
            { "CDF", new() { CurrencyCode = "CDF", CountryName = "Democratic Republic of Congo", CurrencyName = "Congolese Franc", Region = "Africa" } },
            { "DJF", new() { CurrencyCode = "DJF", CountryName = "Djibouti", CurrencyName = "Djiboutian Franc", Region = "Africa" } },
            { "ERN", new() { CurrencyCode = "ERN", CountryName = "Eritrea", CurrencyName = "Eritrean Nakfa", Region = "Africa" } },
            { "ETB", new() { CurrencyCode = "ETB", CountryName = "Ethiopia", CurrencyName = "Ethiopian Birr", Region = "Africa" } },
            { "GMD", new() { CurrencyCode = "GMD", CountryName = "Gambia", CurrencyName = "Gambian Dalasi", Region = "Africa" } },
            { "GNF", new() { CurrencyCode = "GNF", CountryName = "Guinea", CurrencyName = "Guinean Franc", Region = "Africa" } },
            { "LRD", new() { CurrencyCode = "LRD", CountryName = "Liberia", CurrencyName = "Liberian Dollar", Region = "Africa" } },
            { "MUR", new() { CurrencyCode = "MUR", CountryName = "Mauritius", CurrencyName = "Mauritian Rupee", Region = "Africa" } },
            { "MWK", new() { CurrencyCode = "MWK", CountryName = "Malawi", CurrencyName = "Malawian Kwacha", Region = "Africa" } },
            { "RWF", new() { CurrencyCode = "RWF", CountryName = "Rwanda", CurrencyName = "Rwandan Franc", Region = "Africa" } },
            { "SCR", new() { CurrencyCode = "SCR", CountryName = "Seychelles", CurrencyName = "Seychellois Rupee", Region = "Africa" } },
            { "SLL", new() { CurrencyCode = "SLL", CountryName = "Sierra Leone", CurrencyName = "Sierra Leonean Leone", Region = "Africa" } },
            { "SOS", new() { CurrencyCode = "SOS", CountryName = "Somalia", CurrencyName = "Somali Shilling", Region = "Africa" } },
            { "SSP", new() { CurrencyCode = "SSP", CountryName = "South Sudan", CurrencyName = "South Sudanese Pound", Region = "Africa" } },
            { "STN", new() { CurrencyCode = "STN", CountryName = "São Tomé & Príncipe", CurrencyName = "São Tomé & Príncipe Dobra", Region = "Africa" } },
            { "SDG", new() { CurrencyCode = "SDG", CountryName = "Sudan", CurrencyName = "Sudanese Pound", Region = "Africa" } },
            { "XOF", new() { CurrencyCode = "XOF", CountryName = "West Africa", CurrencyName = "West African CFA Franc", Region = "Africa" } },
            { "XAF", new() { CurrencyCode = "XAF", CountryName = "Central Africa", CurrencyName = "Central African CFA Franc", Region = "Africa" } },
        };

        public static CurrencyCountryData? GetCountryData(string currencyCode) =>
            string.IsNullOrWhiteSpace(currencyCode) ? null : 
            CurrencyMapping.TryGetValue(currencyCode.ToUpper(), out var data) ? data : null;

        public static List<CurrencyCountryData> GetCurrenciesByRegion(string region) =>
            CurrencyMapping.Values
                .Where(x => x.Region?.Equals(region, StringComparison.OrdinalIgnoreCase) ?? false)
                .OrderBy(x => x.CurrencyCode)
                .ToList();

        public static List<string> GetAllRegions() =>
            CurrencyMapping.Values
                .Select(x => x.Region)
                .Where(x => !string.IsNullOrEmpty(x))
                .Distinct()
                .OrderBy(x => x)
                .ToList()!;
    }
}
