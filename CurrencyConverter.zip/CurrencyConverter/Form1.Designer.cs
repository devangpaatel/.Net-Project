﻿namespace CurrencyConverter
{
    partial class Form1
    {
       
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code


        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblFromCurrency = new Label();
            cmbFromCurrency = new ComboBox();
            lblToCurrency = new Label();
            cmbToCurrency = new ComboBox();
            lblAmount = new Label();
            txtAmount = new TextBox();
            btnConvert = new Button();
            btnRefresh = new Button();
            lblResult = new Label();
            txtResult = new TextBox();
            lblExchangeRate = new Label();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.BackColor = Color.FromArgb(245, 247, 250);
            lblTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(0, 102, 204);
            lblTitle.Location = new Point(20, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(388, 46);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "💱 Currency Converter";
            // 
            // lblFromCurrency
            // 
            lblFromCurrency.AutoSize = true;
            lblFromCurrency.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblFromCurrency.ForeColor = Color.FromArgb(50, 50, 50);
            lblFromCurrency.Location = new Point(20, 71);
            lblFromCurrency.Name = "lblFromCurrency";
            lblFromCurrency.Size = new Size(162, 23);
            lblFromCurrency.TabIndex = 1;
            lblFromCurrency.Text = "📤 From Currency:";
            // 
            // cmbFromCurrency
            // 
            cmbFromCurrency.BackColor = Color.White;
            cmbFromCurrency.DropDownHeight = 150;
            cmbFromCurrency.FormattingEnabled = true;
            cmbFromCurrency.IntegralHeight = false;
            cmbFromCurrency.Location = new Point(20, 97);
            cmbFromCurrency.Name = "cmbFromCurrency";
            cmbFromCurrency.Size = new Size(400, 28);
            cmbFromCurrency.TabIndex = 2;
            // 
            // lblToCurrency
            // 
            lblToCurrency.AutoSize = true;
            lblToCurrency.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblToCurrency.ForeColor = Color.FromArgb(50, 50, 50);
            lblToCurrency.Location = new Point(20, 135);
            lblToCurrency.Name = "lblToCurrency";
            lblToCurrency.Size = new Size(138, 23);
            lblToCurrency.TabIndex = 3;
            lblToCurrency.Text = "📥 To Currency:";
            // 
            // cmbToCurrency
            // 
            cmbToCurrency.BackColor = Color.White;
            cmbToCurrency.DropDownHeight = 150;
            cmbToCurrency.FormattingEnabled = true;
            cmbToCurrency.IntegralHeight = false;
            cmbToCurrency.Location = new Point(20, 157);
            cmbToCurrency.Name = "cmbToCurrency";
            cmbToCurrency.Size = new Size(400, 28);
            cmbToCurrency.TabIndex = 4;
            cmbToCurrency.SelectedIndexChanged += cmbToCurrency_SelectedIndexChanged;
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblAmount.ForeColor = Color.FromArgb(50, 50, 50);
            lblAmount.Location = new Point(20, 195);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(109, 23);
            lblAmount.TabIndex = 5;
            lblAmount.Text = "💰 Amount:";
            // 
            // txtAmount
            // 
            txtAmount.BackColor = Color.FromArgb(248, 249, 250);
            txtAmount.BorderStyle = BorderStyle.FixedSingle;
            txtAmount.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            txtAmount.ForeColor = Color.FromArgb(0, 102, 204);
            txtAmount.Location = new Point(20, 217);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(180, 32);
            txtAmount.TabIndex = 6;
            txtAmount.Text = "1";
            txtAmount.TextAlign = HorizontalAlignment.Right;
            // 
            // btnConvert
            // 
            btnConvert.BackColor = Color.FromArgb(0, 150, 255);
            btnConvert.Cursor = Cursors.Hand;
            btnConvert.FlatStyle = FlatStyle.Flat;
            btnConvert.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnConvert.ForeColor = Color.White;
            btnConvert.Location = new Point(20, 270);
            btnConvert.Name = "btnConvert";
            btnConvert.Size = new Size(197, 45);
            btnConvert.TabIndex = 7;
            btnConvert.Text = "⚡ Convert";
            btnConvert.UseVisualStyleBackColor = false;
            btnConvert.Click += BtnConvert_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = Color.FromArgb(34, 177, 76);
            btnRefresh.Cursor = Cursors.Hand;
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnRefresh.ForeColor = Color.White;
            btnRefresh.Location = new Point(237, 270);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(183, 45);
            btnRefresh.TabIndex = 8;
            btnRefresh.Text = "🔄 Refresh ";
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Click += BtnRefresh_Click;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblResult.ForeColor = Color.FromArgb(50, 50, 50);
            lblResult.Location = new Point(20, 330);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(93, 23);
            lblResult.TabIndex = 9;
            lblResult.Text = "✨ Result:";
            // 
            // txtResult
            // 
            txtResult.BackColor = Color.FromArgb(235, 245, 255);
            txtResult.BorderStyle = BorderStyle.FixedSingle;
            txtResult.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            txtResult.ForeColor = Color.FromArgb(0, 150, 255);
            txtResult.Location = new Point(20, 352);
            txtResult.Name = "txtResult";
            txtResult.ReadOnly = true;
            txtResult.Size = new Size(400, 39);
            txtResult.TabIndex = 10;
            txtResult.TextAlign = HorizontalAlignment.Right;
            txtResult.TextChanged += txtResult_TextChanged;
            // 
            // lblExchangeRate
            // 
            lblExchangeRate.AutoSize = true;
            lblExchangeRate.Font = new Font("Segoe UI", 9F);
            lblExchangeRate.ForeColor = Color.FromArgb(100, 100, 100);
            lblExchangeRate.Location = new Point(20, 385);
            lblExchangeRate.MaximumSize = new Size(740, 0);
            lblExchangeRate.Name = "lblExchangeRate";
            lblExchangeRate.Size = new Size(0, 20);
            lblExchangeRate.TabIndex = 11;
            // 
            // statusStrip1
            // 
            statusStrip1.BackColor = Color.FromArgb(235, 245, 255);
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1 });
            statusStrip1.Location = new Point(0, 421);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(840, 29);
            statusStrip1.TabIndex = 12;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            toolStripStatusLabel1.ForeColor = Color.FromArgb(0, 102, 204);
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(59, 23);
            toolStripStatusLabel1.Text = "Ready";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(245, 247, 250);
            ClientSize = new Size(840, 450);
            Controls.Add(statusStrip1);
            Controls.Add(lblExchangeRate);
            Controls.Add(txtResult);
            Controls.Add(lblResult);
            Controls.Add(btnRefresh);
            Controls.Add(btnConvert);
            Controls.Add(txtAmount);
            Controls.Add(lblAmount);
            Controls.Add(cmbToCurrency);
            Controls.Add(lblToCurrency);
            Controls.Add(cmbFromCurrency);
            Controls.Add(lblFromCurrency);
            Controls.Add(lblTitle);
            Name = "Form1";
            Text = "Currency Converter";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblFromCurrency;
        private ComboBox cmbFromCurrency;
        private Label lblToCurrency;
        private ComboBox cmbToCurrency;
        private Label lblAmount;
        private TextBox txtAmount;
        private Button btnConvert;
        private Button btnRefresh;
        private Label lblResult;
        private TextBox txtResult;
        private Label lblExchangeRate;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
    }
}
