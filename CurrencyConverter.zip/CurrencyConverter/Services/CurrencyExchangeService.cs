using CurrencyConverter.Models;

namespace CurrencyConverter.Services
{
    /// <summary>
    /// Optimized service for currency exchange rates with worldwide coverage
    /// Contains 100+ valid country currencies with realistic exchange rates
    /// </summary>
    public class CurrencyExchangeService : IDisposable
    {
        private bool _disposed = false;
        private static readonly DateTime LastUpdated = new(2026, 2, 15);

        /// <summary>
        /// Comprehensive exchange rates database with EUR as base currency
        /// Contains 100+ valid country currencies only (no duplicates)
        /// </summary>
        private static readonly Dictionary<string, decimal> ExchangeRates = new()
        {
            // Europe
            { "EUR", 1.0000m },
            { "GBP", 0.8485m },
            { "CHF", 0.9515m },
            { "SEK", 12.0050m },
            { "NOK", 12.2650m },
            { "DKK", 7.7250m },
            { "ISK", 152.8950m },
            { "CZK", 25.1450m },
            { "HUF", 399.2850m },
            { "PLN", 4.5750m },
            { "RON", 5.1950m },
            { "HRK", 7.8550m },
            { "BGN", 1.9850m },
            { "RSD", 121.9850m },
            { "BAM", 1.9850m },
            { "ALL", 109.5850m },
            { "MDL", 19.7550m },
            { "UAH", 45.3250m },
            { "BYN", 3.7250m },
            { "GEL", 3.1350m },

            // Americas
            { "USD", 1.1485m },
            { "CAD", 1.5650m },
            { "MXN", 19.8250m },
            { "BRL", 5.7650m },
            { "ARS", 1085.5000m },
            { "CLP", 1062.2500m },
            { "COP", 4685.2500m },
            { "PEN", 4.2750m },
            { "UYU", 44.6250m },
            { "BOB", 7.9650m },
            { "VES", 43.2500m },
            { "JMD", 176.2500m },
            { "TTD", 7.8250m },
            { "BSD", 1.1485m },
            { "BZD", 2.3250m },
            { "CRC", 594.5000m },
            { "GTQ", 8.9950m },
            { "HNL", 28.3250m },

            // Asia-Pacific
            { "JPY", 154.8250m },
            { "CNY", 8.3150m },
            { "INR", 96.2500m },
            { "SGD", 1.5350m },
            { "HKD", 8.9750m },
            { "AUD", 1.7550m },
            { "NZD", 1.8950m },
            { "KRW", 1508.5000m },
            { "TWD", 36.1250m },
            { "THB", 40.4250m },
            { "MYR", 5.1250m },
            { "PHP", 64.3850m },
            { "IDR", 18125.5000m },
            { "PKR", 321.2500m },
            { "BDT", 120.9250m },
            { "LKR", 371.2500m },
            { "MMK", 2418.5250m },
            { "KHR", 4718.7500m },
            { "LAK", 11725.2500m },
            { "VND", 28325.7500m },
            { "MNT", 4051.2500m },
            { "KGS", 100.4250m },
            { "TJD", 12.3250m },
            { "TMT", 4.0450m },
            { "AFN", 72.2500m },
            { "NPR", 151.8750m },
            { "BTN", 95.6250m },
            { "MVR", 17.7750m },
            { "FJD", 2.5750m },
            { "WST", 3.0850m },
            { "SBD", 9.6750m },
            { "PNG", 4.0450m },
            { "VUV", 135.2500m },

            // Middle East & North Africa
            { "AED", 4.2150m },
            { "SAR", 4.3150m },
            { "QAR", 4.1850m },
            { "KWD", 0.3535m },
            { "BHD", 0.4335m },
            { "OMR", 0.4425m },
            { "JOD", 0.8165m },
            { "ILS", 4.2650m },
            { "EGP", 35.8250m },
            { "TND", 3.6250m },
            { "DZD", 154.3750m },
            { "MAD", 11.4250m },
            { "LBP", 17285.5000m },
            { "SYP", 2955.2500m },
            { "IQD", 1505.5000m },

            // Caucasus & Central Asia
            { "AMD", 444.2500m },
            { "AZN", 1.9650m },
            { "KZT", 507.5000m },
            { "UZS", 13825.2500m },

            // Africa
            { "ZAR", 21.5250m },
            { "NGN", 1703.2500m },
            { "GHS", 14.0650m },
            { "KES", 152.2500m },
            { "TZS", 2975.7500m },
            { "UGX", 4315.2500m },
            { "ZMW", 29.9750m },
            { "ZWL", 37025.5000m },
            { "BWP", 15.7250m },
            { "LSL", 21.5250m },
            { "MZN", 73.6850m },
            { "AOA", 957.5000m },
            { "BIF", 2965.2500m },
            { "CDF", 2805.2500m },
            { "DJF", 204.2500m },
            { "ERN", 17.3150m },
            { "ETB", 61.6850m },
            { "GMD", 71.4250m },
            { "GNF", 9856.2500m },
            { "LRD", 203.1250m },
            { "MUR", 49.5750m },
            { "MWK", 1242.7500m },
            { "RWF", 1485.2500m },
            { "SCR", 15.7250m },
            { "SLL", 22451.2500m },
            { "SOS", 659.2500m },
            { "SSP", 443.5000m },
            { "STN", 22.9850m },
            { "SDG", 525.2500m },
            { "XOF", 684.2500m },
            { "XAF", 684.2500m }
        };

        /// <summary>
        /// Get all available currency codes sorted alphabetically
        /// </summary>
        public async Task<List<string>> GetAvailableCurrenciesAsync()
        {
            try
            {
                var currencies = ExchangeRates.Keys.OrderBy(x => x).ToList();
                return await Task.FromResult(currencies);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to load currencies: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Get all available currencies with names (Code - Country Currency format)
        /// </summary>
        public async Task<List<string>> GetAvailableCurrenciesWithNamesAsync()
        {
            try
            {
                var currencyList = new List<string>();

                foreach (var code in ExchangeRates.Keys.OrderBy(x => x))
                {
                    var countryData = CurrencyCountryMapper.GetCountryData(code);
                    string displayName;

                    if (countryData != null)
                    {
                        displayName = $"{code} - {countryData.CurrencyName} ({countryData.CountryName})";
                    }
                    else
                    {
                        displayName = code;
                    }

                    currencyList.Add(displayName);
                }

                return await Task.FromResult(currencyList);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to load currencies: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Extract currency code from formatted string (e.g., "USD - US Dollar (United States)" returns "USD")
        /// </summary>
        public static string ExtractCurrencyCode(string formattedCurrency)
        {
            if (string.IsNullOrWhiteSpace(formattedCurrency))
                return string.Empty;

            var parts = formattedCurrency.Split(new[] { " - " }, StringSplitOptions.None);
            return parts.Length > 0 ? parts[0].Trim() : string.Empty;
        }

        /// <summary>
        /// Convert amount from one currency to another
        /// </summary>
        public async Task<ConversionResult> ConvertCurrencyAsync(string fromCurrency, string toCurrency, decimal amount)
        {
            ValidateConversionInputs(fromCurrency, toCurrency, amount);

            fromCurrency = fromCurrency.ToUpper();
            toCurrency = toCurrency.ToUpper();

            try
            {
                if (!ExchangeRates.ContainsKey(fromCurrency))
                    throw new InvalidOperationException($"Currency {fromCurrency} not supported");
                if (!ExchangeRates.ContainsKey(toCurrency))
                    throw new InvalidOperationException($"Currency {toCurrency} not supported");

                var exchangeRate = ExchangeRates[toCurrency] / ExchangeRates[fromCurrency];
                var convertedAmount = amount * exchangeRate;

                var fromCountryData = CurrencyCountryMapper.GetCountryData(fromCurrency);
                var toCountryData = CurrencyCountryMapper.GetCountryData(toCurrency);

                return await Task.FromResult(new ConversionResult
                {
                    Amount = amount,
                    FromCurrency = fromCurrency,
                    FromCountry = fromCountryData?.CountryName ?? "Unknown",
                    ToCurrency = toCurrency,
                    ToCountry = toCountryData?.CountryName ?? "Unknown",
                    ExchangeRate = exchangeRate,
                    ConvertedAmount = convertedAmount,
                    LastUpdated = LastUpdated
                });
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException($"Conversion failed: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Validate conversion inputs
        /// </summary>
        private void ValidateConversionInputs(string fromCurrency, string toCurrency, decimal amount)
        {
            if (string.IsNullOrWhiteSpace(fromCurrency))
                throw new ArgumentException("From currency cannot be empty", nameof(fromCurrency));
            if (string.IsNullOrWhiteSpace(toCurrency))
                throw new ArgumentException("To currency cannot be empty", nameof(toCurrency));
            if (amount < 0)
                throw new ArgumentException("Amount cannot be negative", nameof(amount));
            if (fromCurrency.ToUpper() == toCurrency.ToUpper())
                throw new ArgumentException("From and To currencies must be different");
        }

        /// <summary>
        /// Get exchange rate between two currencies
        /// </summary>
        public decimal GetExchangeRate(string fromCurrency, string toCurrency)
        {
            fromCurrency = fromCurrency.ToUpper();
            toCurrency = toCurrency.ToUpper();

            if (fromCurrency == toCurrency)
                return 1m;

            if (!ExchangeRates.ContainsKey(fromCurrency) || !ExchangeRates.ContainsKey(toCurrency))
                throw new InvalidOperationException("One or both currencies not found");

            return ExchangeRates[toCurrency] / ExchangeRates[fromCurrency];
        }

        /// <summary>
        /// Get country information for a currency
        /// </summary>
        public CurrencyCountryData? GetCountryData(string currencyCode)
        {
            return CurrencyCountryMapper.GetCountryData(currencyCode);
        }

        /// <summary>
        /// Get all currencies for a specific region
        /// </summary>
        public List<CurrencyCountryData> GetCurrenciesByRegion(string region)
        {
            return CurrencyCountryMapper.GetCurrenciesByRegion(region);
        }

        /// <summary>
        /// Get all available regions
        /// </summary>
        public List<string> GetAllRegions()
        {
            return CurrencyCountryMapper.GetAllRegions();
        }

        /// <summary>
        /// Get all currencies with country information
        /// </summary>
        public List<CurrencyCountryData> GetAllCurrenciesWithCountries()
        {
            return CurrencyCountryMapper.CurrencyMapping.Values
                .OrderBy(x => x.CurrencyCode)
                .ToList();
        }

        /// <summary>
        /// Get statistics about available currencies
        /// </summary>
        public (int Total, int Regions, List<string> RegionsList) GetCurrencyStatistics()
        {
            var regions = GetAllRegions();
            return (ExchangeRates.Count, regions.Count, regions);
        }

        /// <summary>
        /// Cleanup resources
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                _disposed = true;
            }
        }
    }
}
